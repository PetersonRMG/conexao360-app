import { useState } from "react";
import { router } from "expo-router";
import {
    Image,
    KeyboardAvoidingView,
    Platform,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import globalStyle from "@/styles/globalStyles";
import { criarTopicosStyle } from "@/styles/criarTopicos";
import { useTema } from "@/contexts/TemaContext";
import MenuSreen from "./menu";

// Complementa o estilo original apenas quando o usuário escolhe o tema claro.
// O fundo preto com imagem do tema escuro permanece intacto.
const estilosClaros = StyleSheet.create({
    container: { backgroundColor: "#FFFFFF" },
    background: { backgroundColor: "#FFFFFF" },
    overlay: { backgroundColor: "transparent" },
    tituloPagina: { color: "#292621" },
    aviso: { color: "#6F655A" },
    card: {
        backgroundColor: "#FDFBF8",
        borderColor: "#E8DED1",
        borderWidth: 1,
    },
    label: { color: "#292621" },
    input: {
        backgroundColor: "#FFFFFF",
        color: "#292621",
        borderColor: "#DBCBB5",
        borderWidth: 1,
    },
    contador: { color: "#6F655A" },
    seletor: {
        backgroundColor: "#FFFFFF",
        borderColor: "#DBCBB5",
        borderWidth: 1,
    },
    txtSeletor: { color: "#292621" },
    opcao: {
        backgroundColor: "#F4EDE3",
        borderColor: "#DBCBB5",
    },
    txtOpcao: { color: "#292621" },
    btnNovaOpcao: {
        backgroundColor: "#FFFFFF",
        borderColor: "#B68B46",
    },
    txtNovaOpcao: { color: "#76551E" },
    areaNovaOpcao: { backgroundColor: "transparent" },
    btnCancelar: {
        backgroundColor: "#FFFFFF",
        borderColor: "#B68B46",
    },
    txtCancelar: { color: "#76551E" },
    txtPublicar: { color: "#171717" },
    txtAdicionarOpcao: { color: "#171717" },
});

const retornoStyles = StyleSheet.create({
    mensagem: {
        paddingHorizontal: 4,
        paddingVertical: 10,
        fontSize: 13,
        lineHeight: 19,
        fontWeight: "600",
    },
});

export default function CriarTopicosScreen() {
    const { tema, coresTema } = useTema();
    const criarTopicosStyles = criarTopicosStyle(coresTema);
    const ehTemaClaro = tema === "claro";

    const [titulo, setTitulo] = useState("");
    const [descricao, setDescricao] = useState("");
    const [opcoes, setOpcoes] = useState(["Direito", "Design", "Eventos 360"]);
    const [novaOpcao, setNovaOpcao] = useState("");
    const [mostrarNovaOpcao, setMostrarNovaOpcao] = useState(false);
    const [mensagem, setMensagem] = useState("");

    const adicionarOpcao = () => {
        const opcao = novaOpcao.trim();
        if (!opcao) {
            setMensagem("Digite o nome da nova opção.");
            return;
        }
        if (opcoes.some((item) => item.toLowerCase() === opcao.toLowerCase())) {
            setMensagem("Essa opção já foi adicionada.");
            return;
        }
        setOpcoes((atual) => [...atual, opcao]);
        setNovaOpcao("");
        setMostrarNovaOpcao(false);
        setMensagem("");
    };

    const removerOpcao = (opcaoRemover: string) => {
        setOpcoes((atual) => atual.filter((opcao) => opcao !== opcaoRemover));
    };

    const publicarTopico = () => {
        if (!titulo.trim()) {
            setMensagem("Informe um título para o tópico.");
            return;
        }
        if (!descricao.trim()) {
            setMensagem("Informe uma descrição para o tópico.");
            return;
        }
        if (opcoes.length < 2) {
            setMensagem("Adicione pelo menos duas opções para votação.");
            return;
        }

        // O código recebido ainda não tem endpoint de criação de tópicos.
        // Não mostrar sucesso, navegar ou limpar campos sem persistir na API.
        setMensagem(
            "O formulário está preenchido, mas a criação de tópicos ainda precisa ser integrada à API."
        );
    };

    return (
        <View style={globalStyle.container}>
            <View
                style={[
                    globalStyle.background,
                    criarTopicosStyles.container,
                    ehTemaClaro && estilosClaros.container,
                ]}
            >
                <View
                    style={[
                        criarTopicosStyles.background,
                        ehTemaClaro && estilosClaros.background,
                    ]}
                >
                    {!ehTemaClaro && (
                        <Image
                            source={require("@/assets/images/img/fundoLogin.png")}
                            style={StyleSheet.absoluteFill}
                            resizeMode="cover"
                        />
                    )}

                    <SafeAreaView style={globalStyle.areaConteudo}>
                        <View
                            style={[
                                criarTopicosStyles.overlay,
                                ehTemaClaro && estilosClaros.overlay,
                            ]}
                        >
                            <KeyboardAvoidingView
                                style={criarTopicosStyles.keyboard}
                                behavior={Platform.OS === "ios" ? "padding" : "height"}
                            >
                                <ScrollView
                                    style={criarTopicosStyles.scroll}
                                    contentContainerStyle={criarTopicosStyles.scrollConteudo}
                                    showsVerticalScrollIndicator={false}
                                    keyboardShouldPersistTaps="handled"
                                >
                                    <View style={criarTopicosStyles.topo}>
                                        <Pressable
                                            style={({ pressed }) => [
                                                criarTopicosStyles.btnVoltar,
                                                pressed && criarTopicosStyles.btnVoltarPressed,
                                            ]}
                                            onPress={() => router.back()}
                                            accessibilityLabel="Voltar"
                                        >
                                            <Image
                                                source={require("@/assets/images/img/left.png")}
                                                style={criarTopicosStyles.voltarImagem}
                                            />
                                        </Pressable>
                                        <Image
                                            source={require("@/assets/images/img/logo.svg")}
                                            style={criarTopicosStyles.logo}
                                        />
                                        <View style={criarTopicosStyles.espacoTopo} />
                                    </View>

                                    <View style={criarTopicosStyles.apresentacao}>
                                        <Text
                                            style={[
                                                criarTopicosStyles.tituloPagina,
                                                ehTemaClaro && estilosClaros.tituloPagina,
                                            ]}
                                        >
                                            Criar{" "}
                                            <Text style={criarTopicosStyles.tituloDourado}>
                                                tópico
                                            </Text>
                                        </Text>
                                        <Text
                                            style={[
                                                criarTopicosStyles.aviso,
                                                ehTemaClaro && estilosClaros.aviso,
                                            ]}
                                        >
                                            Compartilhe um assunto relevante com a comunidade.
                                        </Text>
                                    </View>

                                    <View
                                        style={[
                                            criarTopicosStyles.card,
                                            ehTemaClaro && estilosClaros.card,
                                        ]}
                                    >
                                        <Text
                                            style={[
                                                criarTopicosStyles.label,
                                                ehTemaClaro && estilosClaros.label,
                                            ]}
                                        >
                                            Título do tópico
                                        </Text>
                                        <TextInput
                                            value={titulo}
                                            onChangeText={setTitulo}
                                            style={[
                                                criarTopicosStyles.input,
                                                ehTemaClaro && estilosClaros.input,
                                            ]}
                                            placeholder="Digite um texto claro e objetivo"
                                            placeholderTextColor={ehTemaClaro ? "#847D74" : "#777777"}
                                            maxLength={55}
                                        />
                                        <Text
                                            style={[
                                                criarTopicosStyles.contador,
                                                ehTemaClaro && estilosClaros.contador,
                                            ]}
                                        >
                                            {titulo.length}/55
                                        </Text>
                                    </View>

                                    <View
                                        style={[
                                            criarTopicosStyles.card,
                                            ehTemaClaro && estilosClaros.card,
                                        ]}
                                    >
                                        <Text
                                            style={[
                                                criarTopicosStyles.label,
                                                ehTemaClaro && estilosClaros.label,
                                            ]}
                                        >
                                            Selecione um ícone
                                        </Text>
                                        <Pressable
                                            style={({ pressed }) => [
                                                criarTopicosStyles.seletor,
                                                ehTemaClaro && estilosClaros.seletor,
                                                pressed && criarTopicosStyles.seletorPressed,
                                            ]}
                                            onPress={() => setMensagem(
                                                "A seleção de ícones também precisa ser concluída junto da integração de tópicos."
                                            )}
                                        >
                                            <Text
                                                style={[
                                                    criarTopicosStyles.txtSeletor,
                                                    ehTemaClaro && estilosClaros.txtSeletor,
                                                ]}
                                            >
                                                Selecione um ícone
                                            </Text>
                                            <Image
                                                source={require("@/assets/images/img/galeria.png")}
                                                style={criarTopicosStyles.iconeSeletor}
                                            />
                                        </Pressable>
                                    </View>

                                    <View
                                        style={[
                                            criarTopicosStyles.card,
                                            ehTemaClaro && estilosClaros.card,
                                        ]}
                                    >
                                        <Text
                                            style={[
                                                criarTopicosStyles.label,
                                                ehTemaClaro && estilosClaros.label,
                                            ]}
                                        >
                                            Descrição
                                        </Text>
                                        <TextInput
                                            value={descricao}
                                            onChangeText={setDescricao}
                                            style={[
                                                criarTopicosStyles.inputDescricao,
                                                ehTemaClaro && estilosClaros.input,
                                            ]}
                                            placeholder="Digite um texto claro e objetivo"
                                            placeholderTextColor={ehTemaClaro ? "#847D74" : "#777777"}
                                            multiline
                                            textAlignVertical="top"
                                            maxLength={150}
                                        />
                                        <Text
                                            style={[
                                                criarTopicosStyles.contador,
                                                ehTemaClaro && estilosClaros.contador,
                                            ]}
                                        >
                                            {descricao.length}/150
                                        </Text>
                                    </View>

                                    <View
                                        style={[
                                            criarTopicosStyles.card,
                                            ehTemaClaro && estilosClaros.card,
                                        ]}
                                    >
                                        <Text
                                            style={[
                                                criarTopicosStyles.label,
                                                ehTemaClaro && estilosClaros.label,
                                            ]}
                                        >
                                            Adicione opções para votação
                                        </Text>
                                        <View style={criarTopicosStyles.areaOpcoes}>
                                            {opcoes.map((opcao) => (
                                                <Pressable
                                                    key={opcao}
                                                    style={[
                                                        criarTopicosStyles.opcao,
                                                        ehTemaClaro && estilosClaros.opcao,
                                                    ]}
                                                    onPress={() => removerOpcao(opcao)}
                                                    accessibilityLabel={`Remover opção ${opcao}`}
                                                >
                                                    <Text
                                                        style={[
                                                            criarTopicosStyles.txtOpcao,
                                                            ehTemaClaro && estilosClaros.txtOpcao,
                                                        ]}
                                                    >
                                                        {opcao} ×
                                                    </Text>
                                                </Pressable>
                                            ))}
                                            <Pressable
                                                style={[
                                                    criarTopicosStyles.btnNovaOpcao,
                                                    ehTemaClaro && estilosClaros.btnNovaOpcao,
                                                ]}
                                                onPress={() => setMostrarNovaOpcao((atual) => !atual)}
                                            >
                                                <Text
                                                    style={[
                                                        criarTopicosStyles.txtNovaOpcao,
                                                        ehTemaClaro && estilosClaros.txtNovaOpcao,
                                                    ]}
                                                >
                                                    + Nova
                                                </Text>
                                            </Pressable>
                                        </View>

                                        {mostrarNovaOpcao && (
                                            <View
                                                style={[
                                                    criarTopicosStyles.areaNovaOpcao,
                                                    ehTemaClaro && estilosClaros.areaNovaOpcao,
                                                ]}
                                            >
                                                <TextInput
                                                    value={novaOpcao}
                                                    onChangeText={setNovaOpcao}
                                                    style={[
                                                        criarTopicosStyles.inputNovaOpcao,
                                                        ehTemaClaro && estilosClaros.input,
                                                    ]}
                                                    placeholder="Nova opção"
                                                    placeholderTextColor={ehTemaClaro ? "#847D74" : "#777777"}
                                                    maxLength={40}
                                                    onSubmitEditing={adicionarOpcao}
                                                />
                                                <Pressable
                                                    style={({ pressed }) => [
                                                        criarTopicosStyles.btnAdicionarOpcao,
                                                        pressed && criarTopicosStyles.btnAdicionarOpcaoPressed,
                                                    ]}
                                                    onPress={adicionarOpcao}
                                                >
                                                    <Text
                                                        style={[
                                                            criarTopicosStyles.txtAdicionarOpcao,
                                                            ehTemaClaro && estilosClaros.txtAdicionarOpcao,
                                                        ]}
                                                    >
                                                        Adicionar
                                                    </Text>
                                                </Pressable>
                                            </View>
                                        )}
                                    </View>

                                    {!!mensagem && (
                                        <Text
                                            accessibilityRole="alert"
                                            style={[
                                                retornoStyles.mensagem,
                                                { color: ehTemaClaro ? "#A33B33" : "#FFD4C9" },
                                            ]}
                                        >
                                            {mensagem}
                                        </Text>
                                    )}

                                    <View style={criarTopicosStyles.areaBotoes}>
                                        <Pressable
                                            style={({ pressed }) => [
                                                criarTopicosStyles.btnPublicar,
                                                pressed && criarTopicosStyles.btnPublicarPressed,
                                            ]}
                                            onPress={publicarTopico}
                                        >
                                            <Text
                                                style={[
                                                    criarTopicosStyles.txtPublicar,
                                                    ehTemaClaro && estilosClaros.txtPublicar,
                                                ]}
                                            >
                                                Publicar
                                            </Text>
                                        </Pressable>
                                        <Pressable
                                            style={({ pressed }) => [
                                                criarTopicosStyles.btnCancelar,
                                                ehTemaClaro && estilosClaros.btnCancelar,
                                                pressed && criarTopicosStyles.btnCancelarPressed,
                                            ]}
                                            onPress={() => router.back()}
                                        >
                                            <Text
                                                style={[
                                                    criarTopicosStyles.txtCancelar,
                                                    ehTemaClaro && estilosClaros.txtCancelar,
                                                ]}
                                            >
                                                Cancelar
                                            </Text>
                                        </Pressable>
                                    </View>
                                </ScrollView>
                                <MenuSreen />
                            </KeyboardAvoidingView>
                        </View>
                    </SafeAreaView>
                </View>
            </View>
        </View>
    );
}
